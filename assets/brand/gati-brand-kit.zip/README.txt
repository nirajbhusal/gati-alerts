गति Gati brand kit
==================

logos/      the logo as vector (SVG) and as PNG (logos/png)
icons/      app icons and favicons
social/     profile pictures, covers, thumbnails and post backgrounds
print/      brand guidelines (PDF)

Rules in short: do not recolour, stretch or rotate the logo; do not combine it
with a government emblem; do not use the name or logo for a fork or another
service. Full guidelines: print/gati-brand-guidelines.pdf and
https://nirajbhusal.github.io/gati-alerts/about/#brand

The name and logo identify the Gati project and are not covered by the open
licences of its code (MIT) and content (CC BY 4.0).
